package com.jsp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdp.model.User;

import Dao.Dao;

@WebServlet("/GetAllDetails")
public class GetAllDetails extends HttpServlet {
	/**
	 * Get the Values from the DAO Layer
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Dao dao = new Dao();
		List<User> userList = dao.selectAllUsers();
		request.setAttribute("listUser1", userList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("ViewAllUser.jsp"); // Passing to JSP PAGE
		dispatcher.forward(request, response);
		//with response Object we are passing the page by Tomcat to view the page, Tomcat is sending the page. 
	}
}
