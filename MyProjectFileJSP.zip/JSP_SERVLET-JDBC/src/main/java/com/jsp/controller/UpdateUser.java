package com.jsp.controller;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.jdp.model.User;

import Dao.Dao;


@WebServlet("/UpdateUser")
public class UpdateUser extends HttpServlet {
	
 

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * Checking If Employee exist or not By UUID 
		 * Checking if the User is Present or not! 
		 * If the User Exist then we Ask the User to Enter the New Updating Values -> goes to JSP Update Page 
		 * 
		 */
		String uuidPass = request.getParameter("id"); //UUID from User Front End
		Dao dao = new Dao();
		User userFromDB = dao.selectUser(uuidPass); //Got the User from DB Here
	
		if (userFromDB != null) 	
		{     		
			RequestDispatcher rd = request.getRequestDispatcher("UpdateUser.jsp");
			rd.forward(request, response);			
		}
		else {		
			RequestDispatcher dispatcher = request.getRequestDispatcher("ErrorPage.jsp");
			dispatcher.forward(request, response); 		
			//Response Object is sending the page 
			//Request Object from where we get get the data from client.
		}
	}	
}
