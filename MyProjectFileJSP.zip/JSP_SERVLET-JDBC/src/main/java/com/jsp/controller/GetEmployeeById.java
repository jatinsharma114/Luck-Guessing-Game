package com.jsp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jdp.model.User;

import Dao.Dao;

@WebServlet("/GetEmployeeById")
public class GetEmployeeById extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String uuidOfUser = request.getParameter("id"); //UUID String 
		Dao dao = new Dao();
		User user1 = dao.selectUser(uuidOfUser);
		
		if (user1 != null) {
			request.setAttribute("UserById", user1);
			RequestDispatcher dispatcher = request.getRequestDispatcher("InsertedUserView.jsp"); // Passing to JSP PAGE
			dispatcher.forward(request, response);
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("ErrorPage.jsp");
			dispatcher.forward(request, response);
		}
	}
}
