package com.jsp.controller;

import java.io.IOException;
import java.sql.SQLException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.jdp.model.User;

import Dao.Dao;


@WebServlet("/UpdateAfter")
public class UpdateAfter extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    /**
	     * Get the Values from JSPage 
	     * Check the conditions to insert the values or to show to Client 
	     * Filter by Skills - Age criteria - name != Null -  
	     * Set the values to Model - Pass to Object to DAO Layer - to DB 
	     */
	
	 	String userEnterId = request.getParameter("id");
		String name = request.getParameter("name");
		String skills = request.getParameter("skills");
		int age = Integer.parseInt(request.getParameter("age"));
		int salary = Integer.parseInt(request.getParameter("salary"));
		String joiningDate = request.getParameter("joiningdate");	
		/**
		 * Filter Adding 
		 */	
		String[] nameArray = new String[] { "java", "C++" };
		boolean found = false;
		// Using For Each loops here
		for (String x : nameArray) {
			if (x.equals(skills)) {
				found = true;
				break;
			}
		}

		if (age > 18 && age < 40 && name != null && found) {
			User userObjectFromFrontEnd = new User(userEnterId, name, skills, age, salary, joiningDate);
			Dao dao = new Dao();
			try {
				dao.updateUser(userObjectFromFrontEnd);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		
			String userExistInDB = "User Exist!";
			request.setAttribute("ExistUser", userExistInDB);
			RequestDispatcher dispatcher = request.getRequestDispatcher("FrontView.jsp");  
			dispatcher.forward(request, response);
		
		}else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("ErrorPage.jsp");
			dispatcher.forward(request, response); 			
		}
	}
}
