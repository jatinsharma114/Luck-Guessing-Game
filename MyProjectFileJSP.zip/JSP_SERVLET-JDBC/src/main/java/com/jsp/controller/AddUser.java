package com.jsp.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.jdp.model.User;

import Dao.Dao;


@WebServlet("/adduser")
public class AddUser extends HttpServlet {
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/**
		 * Get the values from User in request.
		 * Passing the values to Model 
		 * Get the Object Of User 
		 * Pass the Object of User to DB from DAO Layer
		 * Show the view in front-end User View Page with RD 
		 */
		
		String name = request.getParameter("name");
		String skills = request.getParameter("skills");
		int age = Integer.parseInt(request.getParameter("age"));
		int salary = Integer.parseInt(request.getParameter("salary"));
		String joiningDate = request.getParameter("joiningdate");
		
		//Logic Part applied to Insert the value - Skills 
		String[] nameArray = new String[] { "java", "C++" };
		boolean found = false;
		// Using For Each loops here
		for (String x : nameArray) {
			if (x.equals(skills)) {
				found = true;
				break;
			}
		}
		
		if (age > 18 && age < 40 && name != null && found) {
			User user = new User(name, skills, age, salary, joiningDate);
			Dao dao = new Dao();
			try {
				dao.addUser(user);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			request.setAttribute("label", user);
			RequestDispatcher rd = request.getRequestDispatcher("UserView.jsp");
			rd.forward(request, response);
		} else {
			RequestDispatcher rd = request.getRequestDispatcher("ErrorPage.jsp");
			rd.forward(request, response);
		}
		/**
		 * With Response Object "Tomcat" show the page to the User.
		 */
	}
}
