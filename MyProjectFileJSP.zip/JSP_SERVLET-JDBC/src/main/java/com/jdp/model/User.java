package com.jdp.model;
public class User {
	protected String id;
	protected String name;
	protected String skills;
	protected int age;
	protected int salary;
	protected String joiningDate;

	public User(String id, String name, String skills, int age, int salary, String joiningDate) {
		super();
		this.id = id;
		this.name = name;
		this.skills = skills;
		this.age = age;
		this.salary = salary;
		this.joiningDate = joiningDate;
	}

	public User(String name, String skills, int age, int salary, String joiningDate) {
		super();
		this.name = name;
		this.skills = skills;
		this.age = age;
		this.salary = salary;
		this.joiningDate = joiningDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", skills=" + skills + ", age=" + age + ", salary=" + salary
				+ ", joiningDate=" + joiningDate + "]";
	}

}
